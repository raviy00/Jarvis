# modules/speaker.py - Text to Speech

import os
import tempfile
from gtts import gTTS
from config import VOICE_LANG, VOICE_SLOW

try:
    import pygame
    pygame.mixer.init()
    PYGAME_AVAILABLE = True
except:
    PYGAME_AVAILABLE = False


def speak(text):
    """Speak text out loud on PC."""
    try:
        print(f"🔊 Jarvis: {text}")
        if not PYGAME_AVAILABLE:
            print("   (pygame not available, text only)")
            return

        tts = gTTS(text=text, lang=VOICE_LANG, slow=VOICE_SLOW)
        audio_file = os.path.join(tempfile.gettempdir(), "jarvis_reply.mp3")
        tts.save(audio_file)

        pygame.mixer.music.load(audio_file)
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)

        os.remove(audio_file)

    except Exception as e:
        print(f"❌ Speaker error: {e}")


def text_to_audio_file(text):
    """Convert text to audio file and return path (for Telegram voice notes)."""
    try:
        tts = gTTS(text=text, lang=VOICE_LANG, slow=VOICE_SLOW)
        tmp = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
        tts.save(tmp.name)
        return tmp.name
    except Exception as e:
        print(f"❌ TTS file error: {e}")
        return None
