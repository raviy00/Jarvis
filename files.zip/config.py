# config.py - Jarvis Configuration
import os
from dotenv import load_dotenv

load_dotenv()

# --- API Keys ---
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = int(os.getenv("TELEGRAM_CHAT_ID"))

# --- LLM ---
GROQ_BASE_URL = "https://api.groq.com/openai/v1"
GROQ_MODEL = "llama-3.3-70b-versatile"

# --- Assistant ---
ASSISTANT_NAME = "Jarvis"
SYSTEM_PROMPT = """You are Jarvis, a smart personal AI assistant for Ravi.
You are helpful, concise, and friendly.
You remember context from previous conversations.
When answering questions, be direct and clear.
When doing assignments, be thorough and academic.
Keep spoken responses short since they will be read aloud.
For assignments or documents, you can be detailed.
Never use markdown symbols like **, ##, or bullet points in spoken responses.
Only use formatting in document/assignment outputs."""

# --- Wake Word ---
WAKE_WORD = "hey jarvis"

# --- Whisper ---
WHISPER_MODEL = "base"
LANGUAGE = "en"

# --- Voice ---
VOICE_LANG = "en"
VOICE_SLOW = False

# --- Audio ---
SAMPLE_RATE = 16000
RECORD_SECONDS = 6
SILENCE_THRESHOLD = 500

# --- Memory ---
MEMORY_FILE = "data/memory.json"
MAX_MEMORY = 30

# --- Morning Briefing ---
BRIEFING_HOUR = 7
BRIEFING_MINUTE = 0

# --- Oracle Server ---
ORACLE_HOST = "your_oracle_server_ip"
ORACLE_USER = "ubuntu"
ORACLE_KEY_PATH = "~/.ssh/id_rsa"
