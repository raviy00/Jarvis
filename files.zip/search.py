# modules/search.py - Web Search using DuckDuckGo (free, no API key)

import requests
from modules.brain import think


def web_search(query):
    """Search DuckDuckGo and return summarized results."""
    try:
        # DuckDuckGo instant answer API
        url = "https://api.duckduckgo.com/"
        params = {
            "q": query,
            "format": "json",
            "no_html": 1,
            "skip_disambig": 1
        }

        response = requests.get(url, params=params, timeout=10)
        data = response.json()

        results = []

        # Abstract (main answer)
        if data.get("AbstractText"):
            results.append(data["AbstractText"])

        # Related topics
        for topic in data.get("RelatedTopics", [])[:3]:
            if isinstance(topic, dict) and topic.get("Text"):
                results.append(topic["Text"])

        if results:
            combined = "\n".join(results)
            # Summarize with Groq
            summary = think(
                f"Summarize this search result about '{query}' in 3-4 sentences:\n{combined}",
                [],
                mode="search"
            )
            return summary
        else:
            return f"I couldn't find specific results for '{query}'. Try rephrasing your search."

    except Exception as e:
        return f"Search failed: {e}"
