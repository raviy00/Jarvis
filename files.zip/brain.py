# modules/brain.py - Groq LLM Integration

from openai import OpenAI
from config import GROQ_API_KEY, GROQ_BASE_URL, GROQ_MODEL, SYSTEM_PROMPT


client = OpenAI(
    api_key=GROQ_API_KEY,
    base_url=GROQ_BASE_URL
)


def think(user_input, conversation_history, mode="normal"):
    """
    Send user input to Groq and get a reply.
    mode: normal | assignment | code | search
    """
    try:
        system = SYSTEM_PROMPT

        if mode == "assignment":
            system += "\nYou are in ASSIGNMENT MODE. Give thorough, academic, well-structured answers. Use proper formatting."
        elif mode == "code":
            system += "\nYou are in CODE MODE. Write clean, well-commented code. Explain what it does."
        elif mode == "search":
            system += "\nYou are in SEARCH MODE. Summarize information clearly and concisely."

        messages = [{"role": "system", "content": system}] + conversation_history + [
            {"role": "user", "content": user_input}
        ]

        response = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=messages,
            max_tokens=1000,
            temperature=0.7
        )

        return response.choices[0].message.content.strip()

    except Exception as e:
        print(f"❌ Groq error: {e}")
        return "Sorry, I had trouble processing that. Please try again."


def detect_mode(user_input):
    """Detect what mode to use based on user input."""
    text = user_input.lower()

    if any(w in text for w in ["assignment", "essay", "report", "write about", "explain in detail", "uni", "university", "homework"]):
        return "assignment"
    elif any(w in text for w in ["code", "program", "script", "function", "debug", "fix this", "write a"]):
        return "code"
    elif any(w in text for w in ["search", "find", "look up", "what is", "who is", "latest", "news"]):
        return "search"
    else:
        return "normal"
