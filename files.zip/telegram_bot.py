# modules/telegram_bot.py - Telegram Interface for Jarvis

import os
import asyncio
import tempfile
from telegram import Update, Bot
from telegram.ext import Application, MessageHandler, CommandHandler, filters, ContextTypes
from modules.brain import think, detect_mode
from modules.memory import load_memory, add_message
from modules.speaker import text_to_audio_file
from modules.search import web_search
from modules.documents import save_as_docx
from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, ASSISTANT_NAME


def is_authorized(update: Update) -> bool:
    """Only respond to your own Telegram account."""
    return update.effective_user.id == TELEGRAM_CHAT_ID


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_authorized(update):
        return
    await update.message.reply_text(
        f"👋 Hey Ravi! I'm {ASSISTANT_NAME}, your personal AI assistant.\n\n"
        "You can:\n"
        "• Send me text messages\n"
        "• Send voice notes\n"
        "• Ask me anything\n"
        "• Say 'assignment: [topic]' for uni work\n"
        "• Say 'search: [query]' to search the web\n"
        "• Say 'save doc' to save last reply as Word file\n"
        "• Say 'clear memory' to reset conversation\n\n"
        "Ready when you are! 🚀"
    )


async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_authorized(update):
        return

    user_input = update.message.text.strip()
    await update.message.chat.send_action("typing")

    # Load memory
    history = load_memory()

    # Handle special commands
    if user_input.lower() == "clear memory":
        from modules.memory import clear_memory
        clear_memory()
        await update.message.reply_text("🧹 Memory cleared! Starting fresh.")
        return

    if user_input.lower().startswith("search:"):
        query = user_input[7:].strip()
        result = web_search(query)
        await update.message.reply_text(f"🔍 *Search Results:*\n\n{result}", parse_mode="Markdown")
        return

    if user_input.lower() == "save doc":
        if history:
            last_reply = history[-1]["content"] if history else "Nothing to save."
            path = save_as_docx(last_reply)
            await update.message.reply_document(document=open(path, "rb"), filename="jarvis_output.docx")
        return

    # Detect mode
    mode = detect_mode(user_input)

    # Get reply from Groq
    reply = think(user_input, history, mode=mode)

    # Save to memory
    add_message(history, "user", user_input)
    add_message(history, "assistant", reply)

    # Send reply
    # Split long messages
    if len(reply) > 4000:
        chunks = [reply[i:i+4000] for i in range(0, len(reply), 4000)]
        for chunk in chunks:
            await update.message.reply_text(chunk)
    else:
        await update.message.reply_text(reply)

    # If assignment mode, offer to save as doc
    if mode == "assignment":
        await update.message.reply_text("💾 Reply 'save doc' to save this as a Word document.")


async def handle_voice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_authorized(update):
        return

    await update.message.chat.send_action("typing")

    # Download voice note
    voice_file = await update.message.voice.get_file()
    with tempfile.NamedTemporaryFile(suffix=".ogg", delete=False) as f:
        await voice_file.download_to_drive(f.name)
        voice_path = f.name

    # Transcribe with Whisper
    import whisper
    model = whisper.load_model("base")
    result = model.transcribe(voice_path)
    user_input = result["text"].strip()
    os.unlink(voice_path)

    await update.message.reply_text(f"🎙️ You said: _{user_input}_", parse_mode="Markdown")

    # Get reply
    history = load_memory()
    mode = detect_mode(user_input)
    reply = think(user_input, history, mode=mode)

    # Save memory
    add_message(history, "user", user_input)
    add_message(history, "assistant", reply)

    # Send text reply
    await update.message.reply_text(reply)

    # Also send as voice note
    audio_path = text_to_audio_file(reply)
    if audio_path:
        with open(audio_path, "rb") as audio:
            await update.message.reply_voice(voice=audio)
        os.unlink(audio_path)


async def send_message(text: str):
    """Send a proactive message to Ravi (for alerts, briefings etc)."""
    bot = Bot(token=TELEGRAM_BOT_TOKEN)
    await bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=text)


def run_bot():
    """Start the Telegram bot."""
    print(f"🤖 {ASSISTANT_NAME} Telegram bot starting...")
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_handler(MessageHandler(filters.VOICE, handle_voice))

    print(f"✅ {ASSISTANT_NAME} is live on Telegram!")
    app.run_polling(drop_pending_updates=True)
