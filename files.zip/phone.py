# modules/phone.py - Android Phone Control via ADB

import subprocess
import time


def adb(command):
    """Run an ADB command and return output."""
    try:
        result = subprocess.run(
            f"adb {command}",
            shell=True, capture_output=True, text=True, timeout=15
        )
        return result.stdout.strip()
    except Exception as e:
        return f"ADB error: {e}"


def is_connected():
    """Check if phone is connected via ADB."""
    output = adb("devices")
    lines = [l for l in output.split("\n") if "device" in l and "List" not in l]
    return len(lines) > 0


def connect_wifi(ip, port=5555):
    """Connect to phone via WiFi ADB."""
    result = adb(f"connect {ip}:{port}")
    return result


def take_screenshot():
    """Take screenshot and pull to PC."""
    adb("shell screencap -p /sdcard/jarvis_screen.png")
    adb("pull /sdcard/jarvis_screen.png data/screenshot.png")
    return "data/screenshot.png"


def send_sms(number, message):
    """Send SMS via ADB."""
    result = adb(f'shell am start -a android.intent.action.SENDTO -d sms:{number} --es sms_body "{message}" --ez exit_on_sent true')
    time.sleep(2)
    adb("shell input keyevent 22")  # Move to send button
    adb("shell input keyevent 66")  # Press enter to send
    return f"SMS sent to {number}"


def open_whatsapp(number, message):
    """Open WhatsApp with pre-filled message."""
    result = adb(f'shell am start -a android.intent.action.VIEW -d "https://wa.me/{number}?text={message}"')
    return f"WhatsApp opened for {number}"


def open_app(package_name):
    """Open an app by package name."""
    result = adb(f"shell monkey -p {package_name} 1")
    return f"Opened {package_name}"


def get_battery():
    """Get battery level."""
    result = adb("shell dumpsys battery | grep level")
    return result


def get_notifications():
    """Get current notifications."""
    result = adb("shell dumpsys notification | grep 'tickerText'")
    return result


def lock_screen():
    adb("shell input keyevent 26")
    return "Screen locked"


def unlock_screen():
    adb("shell input keyevent 26")
    time.sleep(0.5)
    adb("shell input swipe 500 1500 500 500")
    return "Screen unlocked"


def set_volume(level):
    """Set media volume (0-15)."""
    for _ in range(15):
        adb("shell input keyevent 25")  # Volume down first
    for _ in range(int(level)):
        adb("shell input keyevent 24")  # Volume up
    return f"Volume set to {level}"
